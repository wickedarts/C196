package com.example.coursescheduler.ViewModel;

public class MyReceiver {
}
