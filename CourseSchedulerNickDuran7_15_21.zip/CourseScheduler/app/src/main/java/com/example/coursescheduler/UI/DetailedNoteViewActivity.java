package com.example.coursescheduler.UI;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.coursescheduler.R;

public class DetailedNoteViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_note_view);
    }
}