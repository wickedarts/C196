package com.example.coursescheduler.UI.Adapters;

import android.content.Intent;
import android.view.LayoutInflater;

import com.example.coursescheduler.Entity.AssessmentEntity;
import com.example.coursescheduler.Entity.NoteEntity;
import com.example.coursescheduler.UI.DetailedNoteViewActivity;

import java.util.List;

public class NoteAdapter {

//    final NoteEntity current = mNotes.get(position);
//    Intent intent = new Intent(context, DetailedNoteViewActivity.class);
//    intent.putExtra("noteID", current.getNoteID());
//    intent.putExtra("courseID", current.getNoteCourseID());
//    intent.putExtra("position", position);
//
//    context.startActivity(intent);
//
//    private final LayoutInflater mInflater;
//    private final Context context;
//    private List<NoteEntity> mNotes;
}
