package com.example.coursescheduler.UI;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ListOfAssessmentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_list_of_assessments);
    }
}