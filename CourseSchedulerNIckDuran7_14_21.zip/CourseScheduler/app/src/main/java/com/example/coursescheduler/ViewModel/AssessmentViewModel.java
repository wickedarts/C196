package com.example.coursescheduler.ViewModel;

public class AssessmentViewModel {
}
